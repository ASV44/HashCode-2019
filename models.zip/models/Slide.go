package models

type Slide struct {
	Tags []string
	Indices []int
}