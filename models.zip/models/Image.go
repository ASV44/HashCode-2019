package models

type Image struct {
	Orientation string
	Tags        []string
	Index	    int
}