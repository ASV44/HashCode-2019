package main

import (
	"bufio"
	"fmt"
	"hashCode/models"
	"log"
	"os"
	"strconv"
	"strings"
)

func main() {
	images := getImages("b_lovely_landscapes.txt")
	slides := createSlides(images)
	path := solve(slides)
	fmt.Println(len(path))
	for _, slide := range path {
		for _, index := range slide.Indices {
			fmt.Print(index)
			fmt.Print(" ")
		}
		fmt.Println()
	}
}

func getImages(fileName string) []models.Image {
	file, err := os.Open(fileName)
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	scanner.Scan()
	images := make([]models.Image, 0)
	index := 0
	for scanner.Scan() {
		data := strings.Fields(scanner.Text())
		tagsAmount, _ := strconv.Atoi(data[1])
		tags := make([]string, 0)
		for i := 2; i < tagsAmount + 2; i++ {
			tags = append(tags, data[i])
		}
		images = append(images, models.Image{Orientation: data[0], Tags: tags, Index: index})
		index += 1
	}

	return images
}

func createSlides(images []models.Image) []models.Slide {
	slides := make([]models.Slide, 0)
	join := false
	var firstVertical models.Image
	for _, image := range images {
		switch image.Orientation {
		case "H":
			slides = append(slides, models.Slide{Tags: image.Tags, Indices: []int{image.Index}})
		case "V":
			if join {
				joinTags := append(firstVertical.Tags, image.Tags...)
				slides = append(slides, models.Slide{Tags: unique(joinTags), Indices: []int{firstVertical.Index, image.Index}})
				join = false
			} else {
				firstVertical = image
				join = true
			}
		}

	}

	return slides
}

func unique(intSlice []string) []string {
	keys := make(map[string]bool)
	list := []string{}
	for _, entry := range intSlice {
		if _, value := keys[entry]; !value {
			keys[entry] = true
			list = append(list, entry)
		}
	}
	return list
}

type Slide_path struct {
	Interest int
	path []models.Slide
}

func min_diff(tags1 []string, tags2[]string) int{
	var common = 0

	for _, t1 := range tags1 {
		for _, t2 := range tags2 {
			if t1 == t2 {
				common = common + 1
			}
		}
	}
	array := []int{common, len(tags1)-common, len(tags2)-common}
	var min_value = min(array)
	return min_value
}

func min(values []int) (min int) {
	if len(values) == 0 {
		return 0
	}

	min = values[0]
	for _, v := range values {
		if (v < min) {
			min = v
		}
	}
	return min
}

func solve(edges []models.Slide) []models.Slide {
	list := make([]models.Slide, len(edges))
	var path []models.Slide
	// var result_list []Slide

	copy(list, edges)

	for i := 1; i < len(edges); i++ {
		max_interest := 0
		current_edge := list[0]
		path = append(path, current_edge)
		list = remove(list, 0)
		var max_edge_index int
		for index2, edge2 := range list {
			value := min_diff(edge2.Tags, current_edge.Tags)
			if value >= max_interest {
				max_interest = value
				max_edge_index = index2
			}
		}

		current_edge = list[max_edge_index]
	}
	//for _, p := range path {
	//	fmt.Printf("%d\n",p.Indices[0])
	//}

	return path
}

func remove(s []models.Slide, i int) []models.Slide {
	s[len(s)-1], s[i] = s[i], s[len(s)-1]
	return s[:len(s)-1]
}
